
DROP SCHEMA IF EXISTS Proj;

CREATE SCHEMA Proj;


DROP TABLE IF EXISTS Proj.ApartmentFeatures;
DROP TABLE IF EXISTS Proj.BuildingFeatures;
DROP TABLE IF EXISTS Proj.Apartments;
DROP TABLE IF EXISTS Proj.Buildings;
DROP TABLE IF EXISTS Proj.ResideRecords;

GO
DROP TABLE IF EXISTS Proj.FeatureB;
DROP TABLE IF EXISTS Proj.FeatureA;
DROP TABLE IF EXISTS Proj.Customers;
DROP TABLE IF EXISTS Proj.Cities;
DROP TABLE IF EXISTS Proj.Owners;
GO

CREATE TABLE Proj.FeatureA
(
   FeatureAID INT NOT NULL IDENTITY(1, 1) PRIMARY KEY ,
   FeatureName NVARCHAR(64) NOT NULL UNIQUE ,
   [Description] NVARCHAR(64) NOT NULL 
);


CREATE TABLE Proj.FeatureB
(
   FeatureBID INT NOT NULL IDENTITY(1, 1) PRIMARY KEY ,
   FeatureName NVARCHAR(64) NOT NULL UNIQUE ,
   [Description] NVARCHAR(64) NOT NULL 
);

CREATE TABLE Proj.Cities
(
   CityID INT NOT NULL IDENTITY(1, 1) PRIMARY KEY ,
   [CityName] NVARCHAR(64) NOT NULL ,
   [State] NVARCHAR(64) NOT NULL,
   Country NVARCHAR(64) NOT NULL 
);


CREATE TABLE Proj.Customers
(
   CustomerID INT NOT NULL IDENTITY(1, 1) PRIMARY KEY ,
   [Name] NVARCHAR(64) NOT NULL ,
   Email NVARCHAR(64) NOT NULL UNIQUE,
   PasswordHash int NOT NULL,
   Tel NVARCHAR(64) NOT NULL ,
   CreatedOn DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET())
);



CREATE TABLE Proj.Owners
(
   OwnerID INT NOT NULL IDENTITY(1, 1) PRIMARY KEY ,
   [Name] NVARCHAR(64) NOT NULL ,
   Email NVARCHAR(64) NOT NULL UNIQUE,
   Tel NVARCHAR(64) NOT NULL ,
   CreatedOn DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET())
);



CREATE TABLE Proj.Buildings
(
    BuildingID INT NOT NULL IDENTITY(1, 1) PRIMARY KEY ,
    OwnerID INT NOT NULL FOREIGN KEY
    REFERENCES Proj.Owners(OwnerID),
    [Address] NVARCHAR(64) NOT NULL,
    CityID INT NOT NULL FOREIGN KEY
    REFERENCES Proj.Cities(CityID),
    YearBuilt  INT NOT NULL,
	TotalFloors INT NOT NULL,
	HeatingType NVARCHAR(64) NOT NULL,
    TimeToBusStop  NVARCHAR(64) NOT NULL ,
    CreatedOn DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET())
);






CREATE TABLE Proj.Apartments
(
    ApartmentID INT NOT NULL IDENTITY(1, 1) PRIMARY KEY ,
    BuildingID INT NOT NULL FOREIGN KEY
    REFERENCES Proj.Buildings(BuildingID),
	ReviewCount INT NOT NULL ,
    AvgReviewScores float NOT NULL ,
    AptNumber int NOT NULL ,
    NumBed int NOT NULL ,
    NumBath int NOT NULL ,
    MonthRent int NOT NULL ,
    Deposit int NOT NULL ,
    Sizesqf int NOT NULL ,
    Availabledate  Date NOT NULL ,
	NumOfParking int NOT NULL ,
	FloorType NVARCHAR(64) NOT NULL ,
	FloorColor  NVARCHAR(64) NOT NULL ,
    CarpetType  NVARCHAR(64) NOT NULL ,
    CarpetColor NVARCHAR(64) NOT NULL ,
    CreatedOn DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET()),
    Updatedon DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET())


);
CREATE TABLE Proj.ResideRecords
(
   ResideID INT NOT NULL IDENTITY(1, 1),
   CustomerID INT NOT NULL FOREIGN KEY
    REFERENCES Proj.Customers(CustomerID),
	ApartmentID INT NOT NULL FOREIGN KEY
    REFERENCES Proj.Apartments(ApartmentID),
   StartDate date NOT NULL ,
   EndDate date NOT NULL ,
   HasReviewed NVARCHAR(64) NOT NULL ,
   ReviewScores int NOT NULL ,
   CreatedOn DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET()),
   Updatedon DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET()),


    PRIMARY KEY(ResideID)
);







CREATE TABLE Proj.BuildingFeatures
(
   BuildingID INT NOT NULL   FOREIGN KEY
    REFERENCES Proj.Buildings(BuildingID),
   FeatureBID INT NOT NULL  FOREIGN KEY
    REFERENCES Proj.FeatureB(FeatureBID),
   CreatedOn DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET()),


   PRIMARY KEY(BuildingID,FeatureBID )
);




CREATE TABLE Proj.ApartmentFeatures
(
   ApartmentID INT NOT NULL    FOREIGN KEY
    REFERENCES Proj.Apartments(ApartmentID),
   FeatureAID INT NOT NULL   FOREIGN KEY
    REFERENCES Proj.FeatureA(FeatureAID),
   CreatedOn DATETIMEOFFSET NOT NULL DEFAULT(SYSDATETIMEOFFSET()),


   PRIMARY KEY(ApartmentID,FeatureAID )
);

