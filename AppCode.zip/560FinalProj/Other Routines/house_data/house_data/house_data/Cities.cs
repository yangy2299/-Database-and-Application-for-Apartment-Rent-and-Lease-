﻿using System;
using System.Collections.Generic;
using System.Text;

namespace house_data
{
    enum Cities
    {
        Dodge_city = 0,
        Garden_city = 1,
        Haysville = 2,
        Kansas_city = 3,
        Emporia = 4,
        Olathe = 5,
        Salina = 6,
        Topeka = 7,
        Lawrence = 8,
        Manhattan = 9
    }
}
