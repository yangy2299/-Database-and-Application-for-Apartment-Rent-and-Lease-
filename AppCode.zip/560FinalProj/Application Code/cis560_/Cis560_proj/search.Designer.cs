﻿namespace Cis560_proj
{
    partial class search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ux_SearchLowPrice = new System.Windows.Forms.TextBox();
            this.ux_SearchHighPrice = new System.Windows.Forms.TextBox();
            this.ux_SearchWithBalcony = new System.Windows.Forms.CheckBox();
            this.ux_SearchWithWasherDryer = new System.Windows.Forms.CheckBox();
            this.ux_SearchPetFriendly = new System.Windows.Forms.CheckBox();
            this.ux_SearchWithGym = new System.Windows.Forms.CheckBox();
            this.ux_SearchWithPool = new System.Windows.Forms.CheckBox();
            this.ux_SearchResultTable = new System.Windows.Forms.DataGridView();
            this.ux_SearchSelectButton = new System.Windows.Forms.Button();
            this.SelectPriceLable = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ux_SearchAverableMonth = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ux_SearchBedNum = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ux_SearchCityName = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ux_SearchTimeToStation = new System.Windows.Forms.ComboBox();
            this.ux_SearchReturnButton = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.numbeth = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.ux_SearchResultTable)).BeginInit();
            this.SuspendLayout();
            // 
            // ux_SearchLowPrice
            // 
            this.ux_SearchLowPrice.Location = new System.Drawing.Point(98, 30);
            this.ux_SearchLowPrice.Multiline = true;
            this.ux_SearchLowPrice.Name = "ux_SearchLowPrice";
            this.ux_SearchLowPrice.Size = new System.Drawing.Size(100, 25);
            this.ux_SearchLowPrice.TabIndex = 0;
            // 
            // ux_SearchHighPrice
            // 
            this.ux_SearchHighPrice.Location = new System.Drawing.Point(252, 30);
            this.ux_SearchHighPrice.Multiline = true;
            this.ux_SearchHighPrice.Name = "ux_SearchHighPrice";
            this.ux_SearchHighPrice.Size = new System.Drawing.Size(100, 25);
            this.ux_SearchHighPrice.TabIndex = 3;
            // 
            // ux_SearchWithBalcony
            // 
            this.ux_SearchWithBalcony.AutoSize = true;
            this.ux_SearchWithBalcony.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchWithBalcony.Location = new System.Drawing.Point(35, 233);
            this.ux_SearchWithBalcony.Name = "ux_SearchWithBalcony";
            this.ux_SearchWithBalcony.Size = new System.Drawing.Size(144, 29);
            this.ux_SearchWithBalcony.TabIndex = 8;
            this.ux_SearchWithBalcony.Text = "WithBalcony";
            this.ux_SearchWithBalcony.UseVisualStyleBackColor = true;
            // 
            // ux_SearchWithWasherDryer
            // 
            this.ux_SearchWithWasherDryer.AutoSize = true;
            this.ux_SearchWithWasherDryer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchWithWasherDryer.Location = new System.Drawing.Point(185, 233);
            this.ux_SearchWithWasherDryer.Name = "ux_SearchWithWasherDryer";
            this.ux_SearchWithWasherDryer.Size = new System.Drawing.Size(190, 29);
            this.ux_SearchWithWasherDryer.TabIndex = 9;
            this.ux_SearchWithWasherDryer.Text = "WithWasherDryer";
            this.ux_SearchWithWasherDryer.UseVisualStyleBackColor = true;
            // 
            // ux_SearchPetFriendly
            // 
            this.ux_SearchPetFriendly.AutoSize = true;
            this.ux_SearchPetFriendly.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchPetFriendly.Location = new System.Drawing.Point(381, 233);
            this.ux_SearchPetFriendly.Name = "ux_SearchPetFriendly";
            this.ux_SearchPetFriendly.Size = new System.Drawing.Size(132, 29);
            this.ux_SearchPetFriendly.TabIndex = 10;
            this.ux_SearchPetFriendly.Text = "PetFriendly";
            this.ux_SearchPetFriendly.UseVisualStyleBackColor = true;
            // 
            // ux_SearchWithGym
            // 
            this.ux_SearchWithGym.AutoSize = true;
            this.ux_SearchWithGym.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchWithGym.Location = new System.Drawing.Point(519, 233);
            this.ux_SearchWithGym.Name = "ux_SearchWithGym";
            this.ux_SearchWithGym.Size = new System.Drawing.Size(115, 29);
            this.ux_SearchWithGym.TabIndex = 11;
            this.ux_SearchWithGym.Text = "WithGym";
            this.ux_SearchWithGym.UseVisualStyleBackColor = true;
            // 
            // ux_SearchWithPool
            // 
            this.ux_SearchWithPool.AutoSize = true;
            this.ux_SearchWithPool.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchWithPool.Location = new System.Drawing.Point(640, 233);
            this.ux_SearchWithPool.Name = "ux_SearchWithPool";
            this.ux_SearchWithPool.Size = new System.Drawing.Size(113, 29);
            this.ux_SearchWithPool.TabIndex = 12;
            this.ux_SearchWithPool.Text = "WithPool";
            this.ux_SearchWithPool.UseVisualStyleBackColor = true;
            // 
            // ux_SearchResultTable
            // 
            this.ux_SearchResultTable.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ux_SearchResultTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ux_SearchResultTable.Location = new System.Drawing.Point(49, 357);
            this.ux_SearchResultTable.Name = "ux_SearchResultTable";
            this.ux_SearchResultTable.RowHeadersWidth = 51;
            this.ux_SearchResultTable.Size = new System.Drawing.Size(706, 397);
            this.ux_SearchResultTable.TabIndex = 13;
            // 
            // ux_SearchSelectButton
            // 
            this.ux_SearchSelectButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchSelectButton.Location = new System.Drawing.Point(515, 281);
            this.ux_SearchSelectButton.Name = "ux_SearchSelectButton";
            this.ux_SearchSelectButton.Size = new System.Drawing.Size(100, 35);
            this.ux_SearchSelectButton.TabIndex = 14;
            this.ux_SearchSelectButton.Text = "Sign in";
            this.ux_SearchSelectButton.UseVisualStyleBackColor = true;
            this.ux_SearchSelectButton.Click += new System.EventHandler(this.ux_SearchSelectButton_Click);
            // 
            // SelectPriceLable
            // 
            this.SelectPriceLable.AutoSize = true;
            this.SelectPriceLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectPriceLable.Location = new System.Drawing.Point(30, 30);
            this.SelectPriceLable.Name = "SelectPriceLable";
            this.SelectPriceLable.Size = new System.Drawing.Size(62, 25);
            this.SelectPriceLable.TabIndex = 15;
            this.SelectPriceLable.Text = "Price:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(213, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 25);
            this.label1.TabIndex = 16;
            this.label1.Text = "To";
            // 
            // ux_SearchAverableMonth
            // 
            this.ux_SearchAverableMonth.DropDownHeight = 110;
            this.ux_SearchAverableMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_SearchAverableMonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchAverableMonth.FormattingEnabled = true;
            this.ux_SearchAverableMonth.IntegralHeight = false;
            this.ux_SearchAverableMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.ux_SearchAverableMonth.Location = new System.Drawing.Point(425, 80);
            this.ux_SearchAverableMonth.Name = "ux_SearchAverableMonth";
            this.ux_SearchAverableMonth.Size = new System.Drawing.Size(121, 33);
            this.ux_SearchAverableMonth.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(259, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 25);
            this.label2.TabIndex = 18;
            this.label2.Text = "Averiable Month:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 25);
            this.label4.TabIndex = 20;
            this.label4.Text = "Num of Bedroom:";
            // 
            // ux_SearchBedNum
            // 
            this.ux_SearchBedNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_SearchBedNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchBedNum.FormattingEnabled = true;
            this.ux_SearchBedNum.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.ux_SearchBedNum.Location = new System.Drawing.Point(198, 127);
            this.ux_SearchBedNum.Name = "ux_SearchBedNum";
            this.ux_SearchBedNum.Size = new System.Drawing.Size(121, 33);
            this.ux_SearchBedNum.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 25);
            this.label5.TabIndex = 22;
            this.label5.Text = "City:";
            // 
            // ux_SearchCityName
            // 
            this.ux_SearchCityName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_SearchCityName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchCityName.FormattingEnabled = true;
            this.ux_SearchCityName.Items.AddRange(new object[] {
            "Dodge_city",
            "Garden_city",
            "Haysville",
            "Kansas_city",
            "Emporia",
            "Olathe",
            "Salina",
            "Topeka",
            "Lawrence",
            "Manhattan"});
            this.ux_SearchCityName.Location = new System.Drawing.Point(98, 80);
            this.ux_SearchCityName.Name = "ux_SearchCityName";
            this.ux_SearchCityName.Size = new System.Drawing.Size(121, 33);
            this.ux_SearchCityName.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(30, 185);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(188, 25);
            this.label6.TabIndex = 24;
            this.label6.Text = "Time to Bus Station:";
            // 
            // ux_SearchTimeToStation
            // 
            this.ux_SearchTimeToStation.CausesValidation = false;
            this.ux_SearchTimeToStation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_SearchTimeToStation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchTimeToStation.FormattingEnabled = true;
            this.ux_SearchTimeToStation.Items.AddRange(new object[] {
            "less than 5 min.",
            "5 - 10 min.",
            "10 - 15 min.",
            "more than 15 min."});
            this.ux_SearchTimeToStation.Location = new System.Drawing.Point(224, 177);
            this.ux_SearchTimeToStation.Name = "ux_SearchTimeToStation";
            this.ux_SearchTimeToStation.Size = new System.Drawing.Size(121, 33);
            this.ux_SearchTimeToStation.TabIndex = 25;
            // 
            // ux_SearchReturnButton
            // 
            this.ux_SearchReturnButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_SearchReturnButton.Location = new System.Drawing.Point(656, 281);
            this.ux_SearchReturnButton.Name = "ux_SearchReturnButton";
            this.ux_SearchReturnButton.Size = new System.Drawing.Size(97, 35);
            this.ux_SearchReturnButton.TabIndex = 26;
            this.ux_SearchReturnButton.Text = "Return";
            this.ux_SearchReturnButton.UseVisualStyleBackColor = true;
            this.ux_SearchReturnButton.Click += new System.EventHandler(this.ux_SearchReturnButton_Click);
            // 
            // result
            // 
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result.Location = new System.Drawing.Point(67, 281);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(98, 35);
            this.result.TabIndex = 30;
            this.result.Text = "Search";
            this.result.UseVisualStyleBackColor = true;
            this.result.Click += new System.EventHandler(this.result_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(552, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 25);
            this.label8.TabIndex = 31;
            this.label8.Text = "Day:";
            // 
            // date
            // 
            this.date.DropDownHeight = 110;
            this.date.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.FormattingEnabled = true;
            this.date.IntegralHeight = false;
            this.date.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.date.Location = new System.Drawing.Point(615, 80);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(121, 33);
            this.date.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(328, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "Num of Bathroom:";
            // 
            // numbeth
            // 
            this.numbeth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.numbeth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numbeth.FormattingEnabled = true;
            this.numbeth.Items.AddRange(new object[] {
            "1",
            "2"});
            this.numbeth.Location = new System.Drawing.Point(494, 132);
            this.numbeth.Name = "numbeth";
            this.numbeth.Size = new System.Drawing.Size(121, 33);
            this.numbeth.TabIndex = 34;
            // 
            // search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 790);
            this.Controls.Add(this.numbeth);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.date);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.result);
            this.Controls.Add(this.ux_SearchReturnButton);
            this.Controls.Add(this.ux_SearchTimeToStation);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ux_SearchCityName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ux_SearchBedNum);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ux_SearchAverableMonth);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SelectPriceLable);
            this.Controls.Add(this.ux_SearchSelectButton);
            this.Controls.Add(this.ux_SearchResultTable);
            this.Controls.Add(this.ux_SearchWithPool);
            this.Controls.Add(this.ux_SearchWithGym);
            this.Controls.Add(this.ux_SearchPetFriendly);
            this.Controls.Add(this.ux_SearchWithWasherDryer);
            this.Controls.Add(this.ux_SearchWithBalcony);
            this.Controls.Add(this.ux_SearchHighPrice);
            this.Controls.Add(this.ux_SearchLowPrice);
            this.Name = "search";
            this.Text = "search";

            ((System.ComponentModel.ISupportInitialize)(this.ux_SearchResultTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ux_SearchLowPrice;
        private System.Windows.Forms.TextBox ux_SearchHighPrice;
        private System.Windows.Forms.CheckBox ux_SearchWithBalcony;
        private System.Windows.Forms.CheckBox ux_SearchWithWasherDryer;
        private System.Windows.Forms.CheckBox ux_SearchPetFriendly;
        private System.Windows.Forms.CheckBox ux_SearchWithGym;
        private System.Windows.Forms.CheckBox ux_SearchWithPool;
        private System.Windows.Forms.DataGridView ux_SearchResultTable;
        private System.Windows.Forms.Button ux_SearchSelectButton;
        private System.Windows.Forms.Label SelectPriceLable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox ux_SearchBedNum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ux_SearchCityName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox ux_SearchTimeToStation;
        private System.Windows.Forms.Button ux_SearchReturnButton;
        private System.Windows.Forms.Button result;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.ComboBox date;
        public System.Windows.Forms.ComboBox ux_SearchAverableMonth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox numbeth;
    }
}