﻿using System;
using System.Collections.Generic;
using System.Text;

namespace house_data
{
    enum Heating
    {
        Furnace,
        Boiler,
        Heat_Pumps
    }
}
