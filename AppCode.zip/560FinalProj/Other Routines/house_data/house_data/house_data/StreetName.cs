﻿using System;
using System.Collections.Generic;
using System.Text;

namespace house_data
{
    enum StreetName
    {
        MACDOUGAL_STREET,
        WATTS_STREET,
        KEMPF_STREET,
        BEAUMONT_STREET,
        DENNETT_STREET,
        PAGE_STREET,
        CROMWELL_STREET,
        HUMPRHRYS_STREET,
        SMOOT_STREET,
        EARL_STREET
    }
}
