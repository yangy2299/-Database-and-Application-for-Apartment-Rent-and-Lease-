﻿using System;
using System.Collections.Generic;
using System.IO;

namespace house_data
{
    class Program
    {
        public static List<List<string>> OwnersTable = new List<List<string>>();
        public static List<List<string>> BuildingsTable = new List<List<string>>();
        public static List<List<string>> ApartmentsTable = new List<List<string>>();
        public static List<List<string>> CustomersTable = new List<List<string>>();
        public static List<List<string>> ResideRecordsTable = new List<List<string>>();
        public static List<List<string>> FeatureATable = new List<List<string>>();
        public static List<List<string>> ApartmentFeaturesTable = new List<List<string>>();
        public static List<List<string>> FeatureBTable = new List<List<string>>();
        public static List<List<string>> BuildingFeaturesTable = new List<List<string>>();

        static void Main(string[] args)
        {
            int OwnerID = 0;
            int BuildingID = 0;
            int ApartmentsID = 0;
            int CustomerID = 0;
            int ResideID = 0;
            int CompanyNameCount = 0;
            int aptIdForCustomer = -4;
            long customerTel = 7857850000;

            Random rd = new Random();

            foreach (CustomerName custName in Enum.GetValues(typeof(CustomerName)))//Custioner Table
            {
                CustomerID++;
                string CustomerName = custName.ToString();
                string CustomerEmail = CustomerName + "@gmail.com";
                string PassWordHash = CustomerName.GetHashCode().ToString();
                customerTel++;
                customerTel = customerTel + OwnerID;

                List<string> customer = new List<string>();
                customer.Add(CustomerName);
                customer.Add(CustomerEmail);
                customer.Add("11111");
                customer.Add(customerTel.ToString());
                Console.WriteLine(CustomerName + ", " + CustomerName.GetHashCode() + ", " + PassWordHash);
                CustomersTable.Add(customer);

                for(int w = 0; w < 2; w++)//ResideRecordsTable
                {
                    ResideID++;
                    aptIdForCustomer = aptIdForCustomer + 5;
                    string StartDate;
                    string EndDate;
                    bool IsScore = true;
                    if(w == 0)
                    {
                        int year = rd.Next(2007, 2019);
                        int month = rd.Next(1, 4);
                        StartDate = "" + year + "-" + month + "-05";
                        year = rd.Next(2010, 2012);
                        month = rd.Next(1, 4);
                        EndDate = "" + year + "-" + month + "-05";
                    }
                    else
                    {
                        int year = rd.Next(2013, 2015);
                        int month = rd.Next(1, 4);
                        StartDate = "" + year + "-" + month + "-05";
                        year = rd.Next(2016, 2018);
                        month = rd.Next(1, 4);
                        EndDate = "" + year + "-" + month + "-05";
                    }
                    int ReviewScores = rd.Next(3, 7);

                    List<string> resideRecord = new List<string>();
                    resideRecord.Add(CustomerID.ToString());
                    resideRecord.Add(aptIdForCustomer.ToString());
                    resideRecord.Add(StartDate);
                    resideRecord.Add(EndDate);
                    resideRecord.Add(IsScore.ToString());
                    resideRecord.Add(ReviewScores.ToString());

                    ResideRecordsTable.Add(resideRecord);
                }
            }

            List<string> featureA = new List<string>();//FeatureATable
            featureA.Add("WithBalcony");
            featureA.Add("This room has a balcony.");
            FeatureATable.Add(featureA);
            featureA = new List<string>();
            featureA.Add("WithWasherDryer");
            featureA.Add("Has indoor washing machine and dryer.");
            FeatureATable.Add(featureA);
            featureA = new List<string>();
            featureA.Add("PetFriendly");
            featureA.Add("You can keep pets.");
            FeatureATable.Add(featureA);

            List<string> featureB = new List<string>();//FeatureBTable
            featureB.Add("WithGym");
            featureB.Add("With Gym inside");
            FeatureBTable.Add(featureB);
            featureB = new List<string>();
            featureB.Add("WithPool");
            featureB.Add("With Pool inside");
            FeatureBTable.Add(featureB);

            for (int u = 1; u < 1001; u++)//ApartmentFeaturesTable
            {
                bool withBalcony = rd.Next(2) > 0;
                bool withWasherDryer = rd.Next(2) > 0;
                bool withPetFriendly = rd.Next(2) > 0;
                List<string> apartmentFeature = new List<string>();
                if (withBalcony)
                {
                    apartmentFeature.Add(u.ToString());
                    apartmentFeature.Add("1");
                    ApartmentFeaturesTable.Add(apartmentFeature);
                    apartmentFeature = new List<string>();
                }
                if (withWasherDryer)
                {
                    apartmentFeature.Add(u.ToString());
                    apartmentFeature.Add("2");
                    ApartmentFeaturesTable.Add(apartmentFeature);
                    apartmentFeature = new List<string>();
                }
                if (withPetFriendly)
                {
                    apartmentFeature.Add(u.ToString());
                    apartmentFeature.Add("3");
                    ApartmentFeaturesTable.Add(apartmentFeature);
                }
            }

            for (int u = 1; u < 201; u++)//BuildingFeaturesTable
            {
                bool withGYM = rd.Next(2) > 0;
                bool withPool = rd.Next(2) > 0;
                List<string> buildingFeature = new List<string>();
                if (withGYM)
                {
                    buildingFeature.Add(u.ToString());
                    buildingFeature.Add("1");
                    BuildingFeaturesTable.Add(buildingFeature);
                    buildingFeature = new List<string>();
                }
                if (withPool)
                {
                    buildingFeature.Add(u.ToString());
                    buildingFeature.Add("2");
                    BuildingFeaturesTable.Add(buildingFeature);
                }
            }

            for(int x = 0; x < 10; x++)//loop though 10 cities
            {
                int AddressNum = 3500;
                
                for(int i = 0; i < 10; i++)//10 owners each city
                {
                    //creat one owner
                    OwnerID++;
                    string Name = Enum.GetName(typeof(CompanyName), CompanyNameCount);
                    string Email = Name + "@gmail.com";
                    long Tel = 7857810000;
                    Tel = Tel + OwnerID;
                    CompanyNameCount++;
                    
                    List<string> owner = new List<string>();
                    owner.Add(Name);
                    owner.Add(Email);
                    owner.Add(Tel.ToString());

                    OwnersTable.Add(owner);//Add owner to Owner table

                    string Street = Enum.GetName(typeof(StreetName), i);

                    //creat two buliding
                    for (int j = 0; j < 2; j++)
                    {
                        BuildingID++;
                        AddressNum++;
                        
                        string CityID = (x + 1).ToString();
                        int yearbuilt = rd.Next(1980, 2007);
                        string YearBuilt = (yearbuilt).ToString();
                        string TotalFloors = (rd.Next(1, 4)).ToString();

                        Array values = Enum.GetValues(typeof(Heating));
                        int index = rd.Next(values.Length);
                        string HeatingType = ((Heating)values.GetValue(index)).ToString();
                        bool WithGym = rd.Next(2) > 0;
                        bool WithPool = rd.Next(2) > 0;

                        int TimeToBusStopTime = rd.Next(1, 21);
                        string TimeToBussStop;
                        if (TimeToBusStopTime > 0 && TimeToBusStopTime <= 5)
                        {
                            TimeToBussStop = "less than 5 min.";
                        }
                        else if (TimeToBusStopTime > 5 && TimeToBusStopTime <= 10)
                        {
                            TimeToBussStop = "5 - 10 min.";
                        }
                        else if (TimeToBusStopTime > 10 && TimeToBusStopTime <= 15)
                        {
                            TimeToBussStop = "10 - 15 min.";
                        }
                        else
                        {
                            TimeToBussStop = "more than 15 min.";
                        }
                        List<string> building = new List<string>();
                        building.Add((OwnerID).ToString());
                        building.Add("" + AddressNum.ToString() + Street);
                        building.Add(CityID);
                        building.Add(YearBuilt);
                        building.Add(TotalFloors);
                        building.Add(HeatingType);
                        building.Add(TimeToBussStop);

                        BuildingsTable.Add(building);//Add bulid to bulidings table


                        //Creat 5 Apartments
                        for(int k = 0; k < 5; k++)
                        {
                            ApartmentsID++;
                            int reviewcount = 0;
                            if(k == 0)
                            {
                                reviewcount = rd.Next(2, 6);
                            }
                            
                            int aveReviewScores = 0;
                            if(reviewcount > 0)
                            {
                                aveReviewScores = rd.Next(2, 6);
                            }
                            string AptNumber = (k + 1).ToString();
                            int numbed = rd.Next(1, 4);
                            string NumBed = (numbed).ToString();
                            int numbath = rd.Next(1, 3);
                            string NumBath = (numbath).ToString();

                            double u1 = 1.0 - rd.NextDouble(); //uniform(0,1] random doubles
                            double u2 = 1.0 - rd.NextDouble();
                            double randStdNormal = Math.Sqrt(-2.0 * Math.Log(u1)) *
                                         Math.Sin(2.0 * Math.PI * u2); //random normal(0,1)
                            int randNormal =
                                         Convert.ToInt32(0 + 6 * randStdNormal); //random normal(mean,stdDev^2)
                            int sizesqf = Convert.ToInt32((80 + 20 * numbed + 10 * numbath + randNormal) * 10.76);
                            string Sizesqf = (sizesqf).ToString();

                            u1 = 1.0 - rd.NextDouble(); //uniform(0,1] random doubles
                            u2 = 1.0 - rd.NextDouble();
                            randStdNormal = Math.Sqrt(-2.0 * Math.Log(u1)) *
                                         Math.Sin(2.0 * Math.PI * u2); //random normal(0,1)
                            randNormal =
                                         Convert.ToInt32(0 + 10 * randStdNormal); //random normal(mean,stdDev^2)
                            int monthrent = 400 + 100 * numbed + 80 * numbath + 10 * (yearbuilt -2001) + randNormal * 10;
                            string MonthRent = (monthrent).ToString();
                            string Deposit = (monthrent * 2).ToString();

                            string AvailableTime = "2020-" + IntMonthToWord(rd.Next(1,13)) + "-" + IntMonthToWord(rd.Next(1, 10));
                            string NumOfParking = (rd.Next(1, 4)).ToString();
                            string FloorType = IntFloorTypeToWord(rd.Next(1, 4));
                            string FloorColor = IntFloorColorToWord(rd.Next(1, 5));
                            string CarpetType = IntCarpetTypeToWord(rd.Next(1, 5));
                            string CarpetColor = IntCarpetColorToWord(rd.Next(1, 5));
                            List<string> apartment = new List<string>();
                            apartment.Add((BuildingID).ToString());
                            apartment.Add(reviewcount.ToString());
                            apartment.Add(aveReviewScores.ToString());
                            apartment.Add(AptNumber);
                            apartment.Add(NumBed);
                            apartment.Add(NumBath);
                            apartment.Add(MonthRent);
                            apartment.Add(Deposit);
                            apartment.Add(Sizesqf);
                            apartment.Add(AvailableTime);
                            apartment.Add(NumOfParking);
                            apartment.Add(FloorType);
                            apartment.Add(FloorColor);
                            apartment.Add(CarpetType);
                            apartment.Add(CarpetColor);

                            ApartmentsTable.Add(apartment);
                        }
                    }
                    
                }
            }
            OutPrint();
        }

        public static string IntMonthToWord(int month)
        {
            switch (month)
            {
                case 1:
                    return ("01");
                case 2:
                    return ("02");
                case 3:
                    return ("03");
                case 4:
                    return ("04");
                case 5:
                    return ("05");
                case 6:
                    return ("06");
                case 7:
                    return ("07");
                case 8:
                    return ("08");
                case 9:
                    return ("09");
                case 10:
                    return ("10");
                case 11:
                    return ("11");
                default:
                    return ("12");
            }
        }


        public static string IntFloorTypeToWord(int num)
        {
            switch (num)
            {
                case 0:
                    return ("Stone");
                case 1:
                    return ("HardWood");
                default:
                    return ("Ceramic");
            }
        }


        public static string IntFloorColorToWord(int num)
        {
            switch (num)
            {
                case 0:
                    return ("White");
                case 1:
                    return ("Brown");
                case 2:
                    return ("WhiteAshed");
                default:
                    return ("Honey");
            }
        }


        public static string IntCarpetTypeToWord(int num)
        {
            switch (num)
            {
                case 0:
                    return ("Nylon");
                case 1:
                    return ("Olefin");
                case 2:
                    return ("Polyester");
                default:
                    return ("Wool");
            }
        }


        public static string IntCarpetColorToWord(int num)
        {
            switch (num)
            {
                case 0:
                    return ("Neatral");
                case 1:
                    return ("Bold");
                case 2:
                    return ("Warm");
                default:
                    return ("Cool");
            }
        }

        /// <summary>
        /// print out solutions
        /// </summary>
        public static void OutPrint()
        {
            string path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\OwnersTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write OwnersTable in to text file
                {
                    foreach (List<string> list in OwnersTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[3];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(N'" + inf[0] + "', N'" + inf[1] + "', N'" + inf[2] + "'),");
                        //(N'Name', N'Email', N'Tel', N'Createdon'), because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\CityTable.txt";
            if (!File.Exists(path))
            {
                using (StreamWriter sw = File.CreateText(path))//write OwnersTable in to text file
                {
                    sw.WriteLine("(N'Dodge_city', N'KS', N'USA'),");
                    sw.WriteLine("(N'Garden_city', N'KS', N'USA'),");
                    sw.WriteLine("(N'Haysville', N'KS', N'USA'),");
                    sw.WriteLine("(N'Kansas_city', N'KS', N'USA'),");
                    sw.WriteLine("(N'Emporia', N'KS', N'USA'),");
                    sw.WriteLine("(N'Olathe', N'KS', N'USA'),");
                    sw.WriteLine("(N'Salina', N'KS', N'USA'),");
                    sw.WriteLine("(N'Topeka', N'KS', N'USA'),");
                    sw.WriteLine("(N'Lawrence', N'KS', N'USA'),");
                    sw.WriteLine("(N'Manhattan', N'KS', N'USA');");
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\BuildingsTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write BuildingsTable in to text file
                {
                    foreach (List<string> list in BuildingsTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[7];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(" + inf[0] + ", N'" + inf[1] + "', " + inf[2] + ", " + inf[3] + ", " + inf[4] + ", N'" + inf[5] + "', N'" + inf[6] + "'),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\ApartmentsTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write ApartmentsTable in to text file
                {
                    foreach (List<string> list in ApartmentsTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[15];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(" + inf[0] + ", " + inf[1] + ", " + inf[2] + ", " + inf[3] + ", " + inf[4] + ", " + inf[5] + ", " + inf[6] + ", " + inf[7]
                            + ", " + inf[8] + ", '" + inf[9] + "', " + inf[10] + ", N'" + inf[11] + "', N'" + inf[12] + "', N'" + inf[13] + "', N'" + inf[14] + "'),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\CustomersTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write CustomersTable in to text file
                {
                    foreach (List<string> list in CustomersTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[4];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(N'" + inf[0] + "', N'" + inf[1] + "', " + inf[2] + ", N'" + inf[3] + "'),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\ResideRecordsTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write ResideRecordsTable in to text file
                {
                    foreach (List<string> list in ResideRecordsTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[6];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(" + inf[0] + ", " + inf[1] + ", '" + inf[2] + "', '" + inf[3] + "', N'" + inf[4] + "', " + inf[5] + "),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\FeatureATable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write FeatureATable in to text file
                {
                    foreach (List<string> list in FeatureATable) // Loop through Table with foreach
                    {
                        string[] inf = new string[2];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(N'" + inf[0] + "', N'" + inf[1] + "'),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\ApartmentFeaturesTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write ApartmentFeaturesTable in to text file
                {
                    foreach (List<string> list in ApartmentFeaturesTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[2];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(" + inf[0] + ", " + inf[1] + "),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\FeatureBTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write FeatureBTable in to text file
                {
                    foreach (List<string> list in FeatureBTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[2];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(N'" + inf[0] + "', N'" + inf[1] + "'),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }

            path = @"C:\Users\Yijun\Desktop\CIS 560\house_data\BuildingFeaturesTable.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))//write BuildingFeaturesTable in to text file
                {
                    foreach (List<string> list in BuildingFeaturesTable) // Loop through Table with foreach
                    {
                        string[] inf = new string[2];
                        int j = 0;
                        foreach (string item in list) // Loop through List with foreach
                        {
                            inf[j] = item;
                            j++;
                        }
                        sw.WriteLine("(" + inf[0] + ", " + inf[1] + "),");
                        //because every line will end by ",", so the last item we need change "," to ";" by hand.
                    }
                }
            }
        }
    }
}
