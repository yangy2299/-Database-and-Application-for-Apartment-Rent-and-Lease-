﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Cis560_proj
{
    public partial class CusPagecs : Form
    {
        string userId;
        string resideId = "";
        string hasreview="";
        string id = "";
        public CusPagecs(string userId)
        {
            InitializeComponent();
            this.userId = userId;

            string connetionString;
            SqlConnection cnn;
            connetionString = "Server=mssql.cs.ksu.edu;Database=da6;User Id=da6;Password=Wanglaoju!2;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            SqlCommand command;
            SqlDataReader dataReader;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql, output = "";
            sql = "select C.[ResideID],C.[ApartmentID] from proj.ResideRecords C where C.[CustomerID] =" + userId + " and C.[EndDate] = " + "'9999-12-30'";
   

            command = new SqlCommand(sql, cnn);



            dataReader = command.ExecuteReader();
            while (dataReader.Read())

            {
                resideId = (dataReader.GetValue(0)).ToString();
                id = (dataReader.GetValue(1)).ToString();
            }



            dataReader.Close();



            command.Dispose();
            cnn.Close();

            if (resideId.Equals(""))
            {
                button1.Enabled = true;
                ux_moveiIn.Enabled = false;
            }
            else
            {
                button1.Enabled = false;
                ux_moveiIn.Enabled = true;
            }



        }

        private void ux_CusReturn_Click(object sender, EventArgs e)
        {
            this.Hide();
            begincs b = new begincs();
            b.Show();
            
        }


        private void ux_CusOK_Click(object sender, EventArgs e)
        {
            id = ux_CusApartmentID.Text;
            string connetionString;
            SqlConnection cnn;
            connetionString = "Server=mssql.cs.ksu.edu;Database=da6;User Id=da6;Password=Wanglaoju!2;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            string q = "select [ApartmentID],[BuildingID],[ReviewCount],[AvgReviewScores],[AptNumber],[NumBed],[NumBath],[MonthRent],[Deposit],[Sizesqf],[AvailableDate],[NumOfParking],[FloorType],[FloorColor],[CarpetType],[CarpetColor] from proj.Apartments a where a.ApartmentID = " + id;

            string q1 = "  select b.[Address], b.TotalFloors, b.YearBuilt,b.HeatingType from proj.Buildings b inner join proj.Apartments a on a.BuildingID = b.BuildingID where a.ApartmentID = " + id;

            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand cmd = new SqlCommand(q, cnn);
            SqlDataAdapter a = new SqlDataAdapter(cmd);

            SqlDataAdapter adapter1 = new SqlDataAdapter();
            SqlCommand cmd1 = new SqlCommand(q1, cnn);
            SqlDataAdapter a1 = new SqlDataAdapter(cmd1);

            DataTable dt = new DataTable();

            a.SelectCommand = cmd;
            a.Fill(dt);
            DataTable dt1 = new DataTable();

            a1.SelectCommand = cmd1;
            a1.Fill(dt1);

            dataGridView1.DataSource = dt;
            dataGridView1.AutoResizeColumns();
            dataGridView2.DataSource = dt1;
            dataGridView2.AutoResizeColumns();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = ux_CusApartmentID.Text;


            DateTime dt = DateTime.Now;
            string s = dt.ToString("yyyy-MM-dd");
            string connetionString;
            SqlConnection cnn;
            connetionString = "Server=mssql.cs.ksu.edu;Database=da6;User Id=da6;Password=Wanglaoju!2;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql ="";

            sql = "INSERT Proj.ResideRecords(CustomerID,ApartmentID,StartDate,EndDate,HasReviewed,ReviewScores) VALUES(";
            sql += userId + "," +id + ",'" +s +"',"+ "'9999-12-30'"+"," +"N'False'"+  "," + "5" + "); ";
        

            command = new SqlCommand(sql, cnn);
            adapter.InsertCommand = new SqlCommand(sql, cnn);
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            cnn.Close();
            MessageBox.Show("You can move in this apartment " + id);
            button1.Enabled = false;
            ux_moveiIn.Enabled = true;

        }

        private void Ux_moveiIn_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = "Server=mssql.cs.ksu.edu;Database=da6;User Id=da6;Password=Wanglaoju!2;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            SqlCommand command;
            SqlDataReader dataReader;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql, output = "";
            sql = "select C.[ResideID],C.[ApartmentID] from proj.ResideRecords C where C.[CustomerID] =" + userId + " and C.[EndDate] = " + "'9999-12-30'";


            command = new SqlCommand(sql, cnn);



            dataReader = command.ExecuteReader();
            while (dataReader.Read())

            {
                resideId = (dataReader.GetValue(0)).ToString();
                id = (dataReader.GetValue(1)).ToString();
            }



            dataReader.Close();



            command.Dispose();
            cnn.Close();


            this.Hide();
            score score = new score(userId,id, resideId);
            score.Show();
        }
    }
}
