﻿namespace Cis560_proj
{
    partial class addapart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ux_AptOwnerName = new System.Windows.Forms.TextBox();
            this.ux_AptStreet = new System.Windows.Forms.TextBox();
            this.ux_AptOwnerTel = new System.Windows.Forms.TextBox();
            this.ux_AptOwnerEmail = new System.Windows.Forms.TextBox();
            this.ux_AptAptNum = new System.Windows.Forms.TextBox();
            this.ux_AptSubmit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ux_AptAvailTime = new System.Windows.Forms.TextBox();
            this.ux_AptSizesqf = new System.Windows.Forms.TextBox();
            this.ux_AptDeposit = new System.Windows.Forms.TextBox();
            this.ux_AptMonthRent = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.ux_AptReturn = new System.Windows.Forms.Button();
            this.ux_City = new System.Windows.Forms.ComboBox();
            this.ux_AptBedNum = new System.Windows.Forms.ComboBox();
            this.ux_AptBathNum = new System.Windows.Forms.ComboBox();
            this.ux_AptNumOfParking = new System.Windows.Forms.ComboBox();
            this.ux_AptFloorType = new System.Windows.Forms.ComboBox();
            this.ux_AptFloorColor = new System.Windows.Forms.ComboBox();
            this.ux_AptCarpetType = new System.Windows.Forms.ComboBox();
            this.ux_AptCarpetColor = new System.Windows.Forms.ComboBox();
            this.ux_AptBuiltYear = new System.Windows.Forms.TextBox();
            this.labe20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ux_AptTotalFloors = new System.Windows.Forms.TextBox();
            this.ux_HeatingType = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.ux_AptTimeToBusStop = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ux_AptOwnerName
            // 
            this.ux_AptOwnerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptOwnerName.Location = new System.Drawing.Point(105, 32);
            this.ux_AptOwnerName.Name = "ux_AptOwnerName";
            this.ux_AptOwnerName.Size = new System.Drawing.Size(153, 30);
            this.ux_AptOwnerName.TabIndex = 0;
            // 
            // ux_AptStreet
            // 
            this.ux_AptStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptStreet.Location = new System.Drawing.Point(105, 147);
            this.ux_AptStreet.Name = "ux_AptStreet";
            this.ux_AptStreet.Size = new System.Drawing.Size(359, 30);
            this.ux_AptStreet.TabIndex = 1;
            // 
            // ux_AptOwnerTel
            // 
            this.ux_AptOwnerTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptOwnerTel.Location = new System.Drawing.Point(576, 32);
            this.ux_AptOwnerTel.Name = "ux_AptOwnerTel";
            this.ux_AptOwnerTel.Size = new System.Drawing.Size(168, 30);
            this.ux_AptOwnerTel.TabIndex = 4;
            // 
            // ux_AptOwnerEmail
            // 
            this.ux_AptOwnerEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptOwnerEmail.Location = new System.Drawing.Point(352, 32);
            this.ux_AptOwnerEmail.Name = "ux_AptOwnerEmail";
            this.ux_AptOwnerEmail.Size = new System.Drawing.Size(157, 30);
            this.ux_AptOwnerEmail.TabIndex = 5;
            // 
            // ux_AptAptNum
            // 
            this.ux_AptAptNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptAptNum.Location = new System.Drawing.Point(624, 147);
            this.ux_AptAptNum.Name = "ux_AptAptNum";
            this.ux_AptAptNum.Size = new System.Drawing.Size(100, 30);
            this.ux_AptAptNum.TabIndex = 7;
            // 
            // ux_AptSubmit
            // 
            this.ux_AptSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptSubmit.Location = new System.Drawing.Point(499, 493);
            this.ux_AptSubmit.Name = "ux_AptSubmit";
            this.ux_AptSubmit.Size = new System.Drawing.Size(100, 75);
            this.ux_AptSubmit.TabIndex = 10;
            this.ux_AptSubmit.Text = "Submit";
            this.ux_AptSubmit.UseVisualStyleBackColor = true;
            this.ux_AptSubmit.Click += new System.EventHandler(this.ux_AptSubmit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(280, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 25);
            this.label2.TabIndex = 12;
            this.label2.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(524, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 25);
            this.label3.TabIndex = 13;
            this.label3.Text = "Tel:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 24);
            this.label4.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(35, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 25);
            this.label5.TabIndex = 15;
            this.label5.Text = "City:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(35, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 25);
            this.label6.TabIndex = 16;
            this.label6.Text = "Street:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(524, 269);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 25);
            this.label7.TabIndex = 17;
            this.label7.Text = "AvailTime:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(524, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 25);
            this.label8.TabIndex = 18;
            this.label8.Text = "Apt Num:";
            // 
            // ux_AptAvailTime
            // 
            this.ux_AptAvailTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptAvailTime.Location = new System.Drawing.Point(635, 266);
            this.ux_AptAvailTime.Name = "ux_AptAvailTime";
            this.ux_AptAvailTime.Size = new System.Drawing.Size(100, 30);
            this.ux_AptAvailTime.TabIndex = 20;
            // 
            // ux_AptSizesqf
            // 
            this.ux_AptSizesqf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptSizesqf.Location = new System.Drawing.Point(369, 266);
            this.ux_AptSizesqf.Name = "ux_AptSizesqf";
            this.ux_AptSizesqf.Size = new System.Drawing.Size(100, 30);
            this.ux_AptSizesqf.TabIndex = 21;
            // 
            // ux_AptDeposit
            // 
            this.ux_AptDeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptDeposit.Location = new System.Drawing.Point(125, 266);
            this.ux_AptDeposit.Name = "ux_AptDeposit";
            this.ux_AptDeposit.Size = new System.Drawing.Size(102, 30);
            this.ux_AptDeposit.TabIndex = 22;
            // 
            // ux_AptMonthRent
            // 
            this.ux_AptMonthRent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptMonthRent.Location = new System.Drawing.Point(643, 209);
            this.ux_AptMonthRent.Name = "ux_AptMonthRent";
            this.ux_AptMonthRent.Size = new System.Drawing.Size(100, 30);
            this.ux_AptMonthRent.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(280, 212);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 25);
            this.label9.TabIndex = 26;
            this.label9.Text = "NumBath:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(524, 212);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 25);
            this.label10.TabIndex = 27;
            this.label10.Text = "MonthRent:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(35, 269);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 25);
            this.label11.TabIndex = 28;
            this.label11.Text = "Deposit:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(280, 269);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 25);
            this.label12.TabIndex = 29;
            this.label12.Text = "Sizesqf:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(35, 212);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 25);
            this.label13.TabIndex = 30;
            this.label13.Text = "NumBed:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(363, 444);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(146, 25);
            this.label14.TabIndex = 31;
            this.label14.Text = "NumOfParking:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(35, 328);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 25);
            this.label15.TabIndex = 33;
            this.label15.Text = "FloorType:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(300, 330);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 25);
            this.label16.TabIndex = 35;
            this.label16.Text = "FloorColor:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(35, 385);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(122, 25);
            this.label17.TabIndex = 37;
            this.label17.Text = "CarpetType:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(300, 385);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(124, 25);
            this.label18.TabIndex = 39;
            this.label18.Text = "CarpetColor:";
            // 
            // ux_AptReturn
            // 
            this.ux_AptReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptReturn.Location = new System.Drawing.Point(646, 493);
            this.ux_AptReturn.Name = "ux_AptReturn";
            this.ux_AptReturn.Size = new System.Drawing.Size(100, 75);
            this.ux_AptReturn.TabIndex = 42;
            this.ux_AptReturn.Text = "Return";
            this.ux_AptReturn.UseVisualStyleBackColor = true;
            this.ux_AptReturn.Click += new System.EventHandler(this.Begin_Click);
            // 
            // ux_City
            // 
            this.ux_City.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_City.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_City.FormattingEnabled = true;
            this.ux_City.Items.AddRange(new object[] {
            "Dodge_city",
            "Garden_city",
            "Haysville",
            "Kansas_city",
            "Emporia",
            "Olathe",
            "Salina",
            "Topeka",
            "Lawrence",
            "Manhattan"});
            this.ux_City.Location = new System.Drawing.Point(93, 92);
            this.ux_City.Name = "ux_City";
            this.ux_City.Size = new System.Drawing.Size(121, 33);
            this.ux_City.TabIndex = 43;
            // 
            // ux_AptBedNum
            // 
            this.ux_AptBedNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptBedNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptBedNum.FormattingEnabled = true;
            this.ux_AptBedNum.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.ux_AptBedNum.Location = new System.Drawing.Point(135, 209);
            this.ux_AptBedNum.Name = "ux_AptBedNum";
            this.ux_AptBedNum.Size = new System.Drawing.Size(121, 33);
            this.ux_AptBedNum.TabIndex = 44;
            // 
            // ux_AptBathNum
            // 
            this.ux_AptBathNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptBathNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptBathNum.FormattingEnabled = true;
            this.ux_AptBathNum.Items.AddRange(new object[] {
            "1",
            "2"});
            this.ux_AptBathNum.Location = new System.Drawing.Point(385, 209);
            this.ux_AptBathNum.Name = "ux_AptBathNum";
            this.ux_AptBathNum.Size = new System.Drawing.Size(121, 33);
            this.ux_AptBathNum.TabIndex = 45;
            // 
            // ux_AptNumOfParking
            // 
            this.ux_AptNumOfParking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptNumOfParking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptNumOfParking.FormattingEnabled = true;
            this.ux_AptNumOfParking.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.ux_AptNumOfParking.Location = new System.Drawing.Point(515, 441);
            this.ux_AptNumOfParking.Name = "ux_AptNumOfParking";
            this.ux_AptNumOfParking.Size = new System.Drawing.Size(121, 33);
            this.ux_AptNumOfParking.TabIndex = 46;
            // 
            // ux_AptFloorType
            // 
            this.ux_AptFloorType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptFloorType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptFloorType.FormattingEnabled = true;
            this.ux_AptFloorType.Items.AddRange(new object[] {
            "HardWood",
            "Ceramic"});
            this.ux_AptFloorType.Location = new System.Drawing.Point(148, 323);
            this.ux_AptFloorType.Name = "ux_AptFloorType";
            this.ux_AptFloorType.Size = new System.Drawing.Size(121, 33);
            this.ux_AptFloorType.TabIndex = 47;
            // 
            // ux_AptFloorColor
            // 
            this.ux_AptFloorColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptFloorColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptFloorColor.FormattingEnabled = true;
            this.ux_AptFloorColor.Items.AddRange(new object[] {
            "Brown",
            "WhiteAshed",
            "Honey"});
            this.ux_AptFloorColor.Location = new System.Drawing.Point(415, 325);
            this.ux_AptFloorColor.Name = "ux_AptFloorColor";
            this.ux_AptFloorColor.Size = new System.Drawing.Size(121, 33);
            this.ux_AptFloorColor.TabIndex = 48;
            // 
            // ux_AptCarpetType
            // 
            this.ux_AptCarpetType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptCarpetType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptCarpetType.FormattingEnabled = true;
            this.ux_AptCarpetType.Items.AddRange(new object[] {
            "Olefin",
            "Polyester",
            "Wool"});
            this.ux_AptCarpetType.Location = new System.Drawing.Point(163, 382);
            this.ux_AptCarpetType.Name = "ux_AptCarpetType";
            this.ux_AptCarpetType.Size = new System.Drawing.Size(121, 33);
            this.ux_AptCarpetType.TabIndex = 49;
            // 
            // ux_AptCarpetColor
            // 
            this.ux_AptCarpetColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptCarpetColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptCarpetColor.FormattingEnabled = true;
            this.ux_AptCarpetColor.Items.AddRange(new object[] {
            "Bold",
            "Warm",
            "Cool"});
            this.ux_AptCarpetColor.Location = new System.Drawing.Point(430, 382);
            this.ux_AptCarpetColor.Name = "ux_AptCarpetColor";
            this.ux_AptCarpetColor.Size = new System.Drawing.Size(121, 33);
            this.ux_AptCarpetColor.TabIndex = 50;
            // 
            // ux_AptBuiltYear
            // 
            this.ux_AptBuiltYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptBuiltYear.Location = new System.Drawing.Point(382, 92);
            this.ux_AptBuiltYear.Name = "ux_AptBuiltYear";
            this.ux_AptBuiltYear.Size = new System.Drawing.Size(99, 30);
            this.ux_AptBuiltYear.TabIndex = 51;
            // 
            // labe20
            // 
            this.labe20.AutoSize = true;
            this.labe20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe20.Location = new System.Drawing.Point(280, 95);
            this.labe20.Name = "labe20";
            this.labe20.Size = new System.Drawing.Size(96, 25);
            this.labe20.TabIndex = 52;
            this.labe20.Text = "BuiltYear:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(35, 444);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(130, 25);
            this.label19.TabIndex = 53;
            this.label19.Text = "HeatingType:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(524, 95);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(116, 25);
            this.label20.TabIndex = 54;
            this.label20.Text = "TotalFloors:";
            // 
            // ux_AptTotalFloors
            // 
            this.ux_AptTotalFloors.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptTotalFloors.Location = new System.Drawing.Point(646, 92);
            this.ux_AptTotalFloors.Name = "ux_AptTotalFloors";
            this.ux_AptTotalFloors.Size = new System.Drawing.Size(85, 30);
            this.ux_AptTotalFloors.TabIndex = 55;
            // 
            // ux_HeatingType
            // 
            this.ux_HeatingType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_HeatingType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_HeatingType.FormattingEnabled = true;
            this.ux_HeatingType.Items.AddRange(new object[] {
            "Furnace",
            "Boiler",
            "Heat_Pumps"});
            this.ux_HeatingType.Location = new System.Drawing.Point(171, 441);
            this.ux_HeatingType.Name = "ux_HeatingType";
            this.ux_HeatingType.Size = new System.Drawing.Size(158, 33);
            this.ux_HeatingType.TabIndex = 56;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(35, 496);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(161, 25);
            this.label21.TabIndex = 57;
            this.label21.Text = "TimeToBusStop:";
            // 
            // ux_AptTimeToBusStop
            // 
            this.ux_AptTimeToBusStop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ux_AptTimeToBusStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ux_AptTimeToBusStop.FormattingEnabled = true;
            this.ux_AptTimeToBusStop.Items.AddRange(new object[] {
            "less than 5 min.",
            "5 - 10 min.",
            "10 - 15 min.",
            "more than 15 min."});
            this.ux_AptTimeToBusStop.Location = new System.Drawing.Point(202, 493);
            this.ux_AptTimeToBusStop.Name = "ux_AptTimeToBusStop";
            this.ux_AptTimeToBusStop.Size = new System.Drawing.Size(158, 33);
            this.ux_AptTimeToBusStop.TabIndex = 58;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(632, 311);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(112, 18);
            this.label22.TabIndex = 59;
            this.label22.Text = "(YYYY-MM-DD)";
            // 
            // addapart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 591);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.ux_AptTimeToBusStop);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.ux_HeatingType);
            this.Controls.Add(this.ux_AptTotalFloors);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.labe20);
            this.Controls.Add(this.ux_AptBuiltYear);
            this.Controls.Add(this.ux_AptCarpetColor);
            this.Controls.Add(this.ux_AptCarpetType);
            this.Controls.Add(this.ux_AptFloorColor);
            this.Controls.Add(this.ux_AptFloorType);
            this.Controls.Add(this.ux_AptNumOfParking);
            this.Controls.Add(this.ux_AptBathNum);
            this.Controls.Add(this.ux_AptBedNum);
            this.Controls.Add(this.ux_City);
            this.Controls.Add(this.ux_AptReturn);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.ux_AptMonthRent);
            this.Controls.Add(this.ux_AptDeposit);
            this.Controls.Add(this.ux_AptSizesqf);
            this.Controls.Add(this.ux_AptAvailTime);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ux_AptSubmit);
            this.Controls.Add(this.ux_AptAptNum);
            this.Controls.Add(this.ux_AptOwnerEmail);
            this.Controls.Add(this.ux_AptOwnerTel);
            this.Controls.Add(this.ux_AptStreet);
            this.Controls.Add(this.ux_AptOwnerName);
            this.Name = "addapart";
            this.Text = "addapart";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ux_AptOwnerName;
        private System.Windows.Forms.TextBox ux_AptStreet;
        private System.Windows.Forms.TextBox ux_AptOwnerTel;
        private System.Windows.Forms.TextBox ux_AptOwnerEmail;
        private System.Windows.Forms.TextBox ux_AptAptNum;
        private System.Windows.Forms.Button ux_AptSubmit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ux_AptAvailTime;
        private System.Windows.Forms.TextBox ux_AptSizesqf;
        private System.Windows.Forms.TextBox ux_AptDeposit;
        private System.Windows.Forms.TextBox ux_AptMonthRent;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button ux_AptReturn;
        private System.Windows.Forms.ComboBox ux_City;
        private System.Windows.Forms.ComboBox ux_AptBedNum;
        private System.Windows.Forms.ComboBox ux_AptBathNum;
        private System.Windows.Forms.ComboBox ux_AptNumOfParking;
        private System.Windows.Forms.ComboBox ux_AptFloorType;
        private System.Windows.Forms.ComboBox ux_AptFloorColor;
        private System.Windows.Forms.ComboBox ux_AptCarpetType;
        private System.Windows.Forms.ComboBox ux_AptCarpetColor;
        private System.Windows.Forms.TextBox ux_AptBuiltYear;
        private System.Windows.Forms.Label labe20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox ux_AptTotalFloors;
        private System.Windows.Forms.ComboBox ux_HeatingType;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox ux_AptTimeToBusStop;
        private System.Windows.Forms.Label label22;
    }
}